
__author__    = "Andre Merzky"
__copyright__ = "Copyright 2012-2013, The SAGA Project"
__license__   = "MIT"


from saga.adaptors.cpi.namespace.entry      import Entry
from saga.adaptors.cpi.namespace.directory  import Directory




